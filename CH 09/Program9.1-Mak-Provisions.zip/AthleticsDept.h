#ifndef ATHLETICSDEPT_H_
#define ATHLETICSDEPT_H_

#include "Sport.h"

class AthleticsDept
{
public:
    void generate_report(const Category& category, const Type& type);
};

#endif /* ATHLETICSDEPT_H_ */
