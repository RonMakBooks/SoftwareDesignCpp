#include "CostReport.h"

int main()
{
    CostReport report;
    report.generate_report();

    return 0;
}
