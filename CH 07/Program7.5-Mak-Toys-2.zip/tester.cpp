#include <iostream>
#include "Toy.h"

int main()
{
    ToyCar car;
    car.print();

    ModelAirplane plane;
    plane.print();

    TrainSet train;
    train.print();

    return 0;
}
