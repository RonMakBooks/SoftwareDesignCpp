#include "Toy.h"

using namespace std;

int main()
{
    ToyCar car;
    car.print();

    ModelAirplane plane;
    plane.print();

    TrainSet train;
    train.print();

    return 0;
}
