#include <iostream>
#include "Queens.h"

using namespace std;

int main()
{
    Queens q;
    q.print_solutions();

    cout << endl << "Done!" << endl;
    return 0;
}
