#include <iostream>

using namespace std;

int main()
{
    int count = 0;

    for (int i = 5; i <= 10; i++)
    {
        count++;
        cout << "count = " << count << ", i = " << i << endl;
    }
}
