#include <iostream>
#include "Date.h"

using namespace std;

int main()
{
    Date date(2025, 2, 4);  // February 4, 2025
    cout << date << endl;

    return 0;
}
