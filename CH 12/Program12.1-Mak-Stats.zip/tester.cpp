#include "BaseballReporter.h"

int main()
{
    BaseballReporter reporter;
    reporter.distribute_content();

    return 0;
}
