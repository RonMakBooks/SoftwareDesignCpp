#ifndef TEAMREPORT_H_
#define TEAMREPORT_H_

#include "Team.h"

class TeamReport
{
public:
    void print(Team& team) const;
};

#endif /* TEAMREPORT_H_ */
