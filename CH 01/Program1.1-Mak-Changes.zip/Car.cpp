#import "Car.h"

void Car::step_on_brake() {}
void Car::insert_key() {}
void Car::turn_key() {}
void Car::step_on_accelerator() {}
