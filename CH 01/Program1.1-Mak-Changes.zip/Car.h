#ifndef CAR_H_
#define CAR_H_

class Car
{
public:
    void step_on_brake();
    void insert_key();
    void turn_key();
    void step_on_accelerator();
};

#endif /* CAR_H_ */
