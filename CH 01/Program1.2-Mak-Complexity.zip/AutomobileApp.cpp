#include "AutomobileApp.h"

void AutomobileApp::accelerate() {}
void AutomobileApp::adjust_headlights() {}
void AutomobileApp::apply_brakes() {}
void AutomobileApp::change_oil() {}
void AutomobileApp::change_tires() {}
void AutomobileApp::check_brakes() {}
void AutomobileApp::check_tires() {}
void AutomobileApp::rotate_tires() {}
void AutomobileApp::shut_off_engine() {}
void AutomobileApp::start_engine() {}
void AutomobileApp::tuneup_engine() {}
void AutomobileApp::turn_left() {}
void AutomobileApp::turn_right() {}
void AutomobileApp::vacuum_car() {}
void AutomobileApp::wash_car() {}
void AutomobileApp::wax_car() {}
