#include "AutomobileApp.h"

int main()
{
    AutomobileApp auto_app;
    auto_app.accelerate();

    return 0;
}
