#include "Pet.h"

int main()
{
    Cat *pet = new Cat();  // inflexible!
    return 0;
}
