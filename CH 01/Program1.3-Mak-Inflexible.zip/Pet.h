#ifndef PET_H_
#define PET_H_

class Pet
{
    // ...
};

class Cat : public Pet
{
    // ...
};

class Dog : public Pet
{
    // ...
};

#endif /* PET_H_ */
