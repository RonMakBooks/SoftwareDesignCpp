#include "Car.h"
#include "Truck.h"

int main()
{
    Car car;
    car.drive();

    Truck truck;
    truck.drive();

    return 0;
}
