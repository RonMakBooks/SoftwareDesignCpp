#include "DemeterAuto.h"

int main()
{
    DemeterAuto demeter_auto;
    demeter_auto.maintain_auto();

    return 0;
}
