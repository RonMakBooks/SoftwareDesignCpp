#include "AthleticsDept.h"
#include "Administration.h"

int main()
{
    AthleticsDept athletics;
    athletics.raise_funds();

    Administration administration;
    administration.aid_fundraising();

    return 0;
}
