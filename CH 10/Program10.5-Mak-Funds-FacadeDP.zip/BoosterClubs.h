#ifndef BOOSTERCLUBS_H_
#define BOOSTERCLUBS_H_

#include <iostream>

using namespace std;

class BoosterClubs
{
public:
    void schedule_meetings()
    {
        cout << "Schedule meetings with booster clubs." << endl;
    }
};

#endif /* BOOSTERCLUBS_H_ */
