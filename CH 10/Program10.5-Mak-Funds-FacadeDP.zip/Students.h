#ifndef STUDENTS_H_
#define STUDENTS_H_

#include <iostream>

using namespace std;

class Students
{
public:
    void collect_fees()
    {
        cout << "Collect student fees." << endl;
    }
};

#endif /* STUDENTS_H_ */
