#include "AthleticsDept.h"
#include "Administration.h"

int main()
{
    AthleticsDept athletics;
    athletics.raise_funds();

    Administration administration;
    administration.raise_funds();

    return 0;
}
