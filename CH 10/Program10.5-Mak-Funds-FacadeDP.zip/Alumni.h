#ifndef ALUMNI_H_
#define ALUMNI_H_

#include <iostream>

using namespace std;

class Alumni
{
public:
    void send_solicitations()
    {
        cout << "Send solicitations to alumni." << endl;
    }
};

#endif /* ALUMNI_H_ */
