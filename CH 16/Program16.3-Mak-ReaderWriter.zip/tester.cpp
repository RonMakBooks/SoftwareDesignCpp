#include <iostream>
#include "Meter.h"

using namespace std;

int main()
{
    Meter meter;
    meter.run();

    cout << endl << "Program done!" << endl;
    return 0;
}
